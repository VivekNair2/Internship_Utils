import exceptions.InvalidTicketException;
import exceptions.ParkingLotFullException;
import models.ParkingReceipt;
import models.PaymentReceipt;
import service.ParkingLot;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ParkingLotTest {
    private ParkingLot parkingLot;

    @BeforeEach
    public void setUp() {
        parkingLot = new ParkingLot();
    }

    static class ParkCarTestCase {
        String description;
        String carNumber;
        String carNumber2;
        Class<? extends Exception> expectedException;

        ParkCarTestCase(String description, String carNumber, String carNumber2, Class<? extends Exception> expectedException) {
            this.description = description;
            this.carNumber = carNumber;
            this.carNumber2 = carNumber2;
            this.expectedException = expectedException;
        }

        ParkCarTestCase(String description, String carNumber) {
            this(description, carNumber, null, null);
        }

        ParkCarTestCase(String description, String carNumber, String carNumber2) {
            this(description, carNumber, carNumber2, null);
        }
    }

    @Test
    public void testShouldHandleParkingCorrectly() {
        ParkCarTestCase[] testCases = {
            new ParkCarTestCase("Should return parking receipt when car is parked", "KA01AB1234"),
            new ParkCarTestCase("Should return different slot numbers when multiple cars are parked", "KA01AB1234", "KA02CD5678")
        };

        for (ParkCarTestCase testCase : testCases) {
            parkingLot = new ParkingLot();

            if (testCase.carNumber2 != null) {
                ParkingReceipt receipt1 = parkingLot.parkCar(testCase.carNumber);
                ParkingReceipt receipt2 = parkingLot.parkCar(testCase.carNumber2);

                assertNotEquals(receipt1.getSlotNumber(), receipt2.getSlotNumber(), testCase.description);
            } else {
                ParkingReceipt receipt = parkingLot.parkCar(testCase.carNumber);

                assertNotNull(receipt, testCase.description);
                assertEquals(testCase.carNumber, receipt.getCarNumber(), testCase.description);
                assertNotNull(receipt.getTicketId(), testCase.description);
                assertTrue(receipt.getSlotNumber() > 0, testCase.description);
                assertNotNull(receipt.getParkingTime(), testCase.description);
            }
        }
    }

    static class UnparkCarTestCase {
        String description;
        String carNumber;
        boolean shouldParkFirst;
        boolean isDoubleUnpark;
        Class<? extends Exception> expectedException;

        UnparkCarTestCase(String description, String carNumber, boolean shouldParkFirst, boolean isDoubleUnpark, Class<? extends Exception> expectedException) {
            this.description = description;
            this.carNumber = carNumber;
            this.shouldParkFirst = shouldParkFirst;
            this.isDoubleUnpark = isDoubleUnpark;
            this.expectedException = expectedException;
        }

        UnparkCarTestCase(String description, String carNumber, boolean shouldParkFirst) {
            this(description, carNumber, shouldParkFirst, false, null);
        }
    }

    @Test
    public void testShouldHandleUnparkingCorrectly() {
        UnparkCarTestCase[] testCases = {
            new UnparkCarTestCase("Should return payment receipt when car is unparked", "KA01AB1234", true),
            new UnparkCarTestCase("Should throw InvalidTicketException when invalid ticket is provided", "INVALID_TICKET", false, false, InvalidTicketException.class),
            new UnparkCarTestCase("Should not allow unparking twice when same ticket is used", "KA02AB5678", true, true, InvalidTicketException.class)
        };

        for (UnparkCarTestCase testCase : testCases) {
            parkingLot = new ParkingLot();

            if (testCase.expectedException != null) {
                if (testCase.isDoubleUnpark) {
                    ParkingReceipt parkingReceipt = parkingLot.parkCar(testCase.carNumber);
                    parkingLot.unparkCar(parkingReceipt.getTicketId());

                    Exception exception = assertThrows(testCase.expectedException, () -> {
                        parkingLot.unparkCar(parkingReceipt.getTicketId());
                    }, testCase.description);
                    assertNotNull(exception, testCase.description);
                } else {
                    Exception exception = assertThrows(testCase.expectedException, () -> {
                        parkingLot.unparkCar(testCase.carNumber);
                    }, testCase.description);
                    assertNotNull(exception, testCase.description);
                }
            } else {
                ParkingReceipt parkingReceipt = parkingLot.parkCar(testCase.carNumber);
                PaymentReceipt paymentReceipt = parkingLot.unparkCar(parkingReceipt.getTicketId());

                assertNotNull(paymentReceipt, testCase.description);
                assertEquals(parkingReceipt.getTicketId(), paymentReceipt.getTicketId(), testCase.description);
                assertEquals(testCase.carNumber, paymentReceipt.getCarNumber(), testCase.description);
                assertTrue(paymentReceipt.getCharge() >= 0, testCase.description);
            }
        }
    }

    static class ParkingLotFullTestCase {
        String description;
        boolean shouldUnparkFirst;
        Class<? extends Exception> expectedException;

        ParkingLotFullTestCase(String description, boolean shouldUnparkFirst, Class<? extends Exception> expectedException) {
            this.description = description;
            this.shouldUnparkFirst = shouldUnparkFirst;
            this.expectedException = expectedException;
        }
    }

    @Test
    public void testShouldHandleParkingLotFullScenarios() {
        ParkingLotFullTestCase[] testCases = {
            new ParkingLotFullTestCase("Should throw ParkingLotFullException when all slots are occupied", false, ParkingLotFullException.class),
            new ParkingLotFullTestCase("Should allow parking after unparking when lot was full", true, null)
        };

        for (ParkingLotFullTestCase testCase : testCases) {
            parkingLot = new ParkingLot();
            ParkingReceipt firstCarReceipt = null;

            for (int i = 1; i <= 100; i++) {
                ParkingReceipt receipt = parkingLot.parkCar("CAR" + i);
                if (i == 1) {
                    firstCarReceipt = receipt;
                }
            }

            if (testCase.shouldUnparkFirst) {
                parkingLot.unparkCar(firstCarReceipt.getTicketId());
                ParkingReceipt newReceipt = parkingLot.parkCar("CAR101");
                assertNotNull(newReceipt, testCase.description);
            } else {
                Exception exception = assertThrows(testCase.expectedException, () -> {
                    parkingLot.parkCar("CAR101");
                }, testCase.description);
                assertNotNull(exception, testCase.description);
            }
        }
    }
}
