import service.ChargeCalculator;
import exceptions.InvalidTimeException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import static org.junit.jupiter.api.Assertions.*;

public class ChargeCalculatorTest {
    private ChargeCalculator chargeCalculator;

    @BeforeEach
    public void setUp() {
        chargeCalculator = new ChargeCalculator();
    }

    static class TestCase {
        String description;
        LocalDateTime parkingTime;
        LocalDateTime unparkingTime;
        double expectedCharge;
        Class<? extends Exception> expectedException;

        TestCase(String description, LocalDateTime parkingTime, LocalDateTime unparkingTime, double expectedCharge, Class<? extends Exception> expectedException) {
            this.description = description;
            this.parkingTime = parkingTime;
            this.unparkingTime = unparkingTime;
            this.expectedCharge = expectedCharge;
            this.expectedException = expectedException;
        }

        TestCase(String description, LocalDateTime parkingTime, LocalDateTime unparkingTime, double expectedCharge) {
            this(description, parkingTime, unparkingTime, expectedCharge, null);
        }
    }

    @Test
    public void testShouldCalculateChargeCorrectly() {
        TestCase[] testCases = {
            new TestCase(
                "Should return 100 when parked for less than 24 hours",
                LocalDateTime.of(2026, 2, 15, 10, 0),
                LocalDateTime.of(2026, 2, 15, 20, 0),
                100.0
            ),
            new TestCase(
                "Should return 150 when parked for 25 hours",
                LocalDateTime.of(2026, 2, 15, 10, 0),
                LocalDateTime.of(2026, 2, 16, 11, 0),
                150.0
            ),
            new TestCase(
                "Should return 200 when parked for 72 hours",
                LocalDateTime.of(2026, 2, 15, 10, 0),
                LocalDateTime.of(2026, 2, 18, 10, 0),
                200.0
            ),
            new TestCase(
                "Should return 0 when unparking time is same as parking time",
                LocalDateTime.of(2026, 2, 15, 10, 0),
                LocalDateTime.of(2026, 2, 15, 10, 0),
                0.0
            ),
            new TestCase(
                "Should throw InvalidTimeException when unparking time is before parking time",
                LocalDateTime.of(2026, 2, 15, 10, 0),
                LocalDateTime.of(2026, 2, 15, 9, 0),
                0.0,
                InvalidTimeException.class
            )
        };

        for (TestCase testCase : testCases) {
            if (testCase.expectedException != null) {
                Exception exception = assertThrows(testCase.expectedException, () -> {
                    chargeCalculator.calculateCharge(testCase.parkingTime, testCase.unparkingTime);
                }, testCase.description);
                assertNotNull(exception, testCase.description);
            } else {
                double actualCharge = chargeCalculator.calculateCharge(testCase.parkingTime, testCase.unparkingTime);
                assertEquals(testCase.expectedCharge, actualCharge, testCase.description);
            }
        }
    }
}
