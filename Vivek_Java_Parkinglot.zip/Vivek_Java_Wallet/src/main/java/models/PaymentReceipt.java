package models;

import interfaces.Receipt;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PaymentReceipt implements Receipt {
    private String ticketId;
    private String carNumber;
    private double charge;
    private LocalDateTime unparkingTime;

    public PaymentReceipt(String ticketId, String carNumber, double charge, LocalDateTime unparkingTime) {
        this.ticketId = ticketId;
        this.carNumber = carNumber;
        this.charge = charge;
        this.unparkingTime = unparkingTime;
    }

    @Override
    public String getTicketId() {
        return ticketId;
    }

    public double getCharge() {
        return charge;
    }

    public String getCarNumber() {
        return carNumber;
    }
}
