package models;

import java.time.LocalDateTime;

public class ParkingSession {
    private String carNumber;
    private int slotNumber;
    private LocalDateTime parkingTime;

    public ParkingSession(String carNumber, int slotNumber, LocalDateTime parkingTime) {
        this.carNumber = carNumber;
        this.slotNumber = slotNumber;
        this.parkingTime = parkingTime;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public int getSlotNumber() {
        return slotNumber;
    }

    public LocalDateTime getParkingTime() {
        return parkingTime;
    }
}
