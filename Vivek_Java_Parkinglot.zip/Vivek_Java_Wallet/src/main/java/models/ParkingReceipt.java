package models;

import interfaces.Receipt;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ParkingReceipt implements Receipt {
    private String ticketId;
    private String carNumber;
    private int slotNumber;
    private LocalDateTime parkingTime;

    public ParkingReceipt(String ticketId, String carNumber, int slotNumber, LocalDateTime parkingTime) {
        this.ticketId = ticketId;
        this.carNumber = carNumber;
        this.slotNumber = slotNumber;
        this.parkingTime = parkingTime;
    }

    @Override
    public String getTicketId() {

        return ticketId;
    }

    public String getCarNumber() {

        return carNumber;
    }

    public int getSlotNumber()
    {
        return slotNumber;
    }

    public LocalDateTime getParkingTime() {
        return parkingTime;
    }


}
