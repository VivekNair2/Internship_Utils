package models;

public class ParkingSlot {
    private int slotNumber;
    private String parkedCarNumber;
    private boolean isOccupied;

    public ParkingSlot(int slotNumber) {
        this.slotNumber = slotNumber;
        this.parkedCarNumber = null;
        this.isOccupied = false;
    }

    public int getSlotNumber() {
        return slotNumber;
    }

    public boolean isOccupied() {
        return isOccupied;
    }

    public void parkCar(String carNumber) {
        this.parkedCarNumber = carNumber;
        this.isOccupied = true;
    }

    public String unparkCar() {
        String carNumber = this.parkedCarNumber;
        this.parkedCarNumber = null;
        this.isOccupied = false;
        return carNumber;
    }
}
