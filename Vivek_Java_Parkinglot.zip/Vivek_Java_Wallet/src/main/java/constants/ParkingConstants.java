package constants;

public class ParkingConstants {
    public static final int TOTAL_PARKING_SPOTS = 100;
    public static final int FIRST_DAY_CHARGE = 100;
    public static final int SUBSEQUENT_DAY_CHARGE = 50;
}
