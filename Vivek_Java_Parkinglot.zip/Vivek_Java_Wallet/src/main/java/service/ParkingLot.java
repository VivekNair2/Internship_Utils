package service;

import constants.ParkingConstants;
import exceptions.InvalidTicketException;
import exceptions.ParkingLotFullException;
import models.ParkingReceipt;
import models.PaymentReceipt;
import models.ParkingSlot;
import models.ParkingSession;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ParkingLot {
    private Map<Integer, ParkingSlot> parkingSlots;
    private Map<String, ParkingSession> activeSessions;
    private ChargeCalculator chargeCalculator;

    public ParkingLot() {
        this.parkingSlots = new HashMap<>();
        this.activeSessions = new HashMap<>();
        this.chargeCalculator = new ChargeCalculator();
        initializeSlots();
    }

    private void initializeSlots() {
        for (int i = 1; i <= ParkingConstants.TOTAL_PARKING_SPOTS; i++) {
            parkingSlots.put(i, new ParkingSlot(i));
        }
    }

    public ParkingReceipt parkCar(String carNumber) {
        ParkingSlot availableSlot = findAvailableSlot();

        if (availableSlot == null) {
            throw new ParkingLotFullException("Parking lot is full");
        }

        availableSlot.parkCar(carNumber);
        String ticketId = generateTicketId();
        LocalDateTime parkingTime = LocalDateTime.now();

        activeSessions.put(ticketId, new ParkingSession(carNumber, availableSlot.getSlotNumber(), parkingTime));

        return new ParkingReceipt(ticketId, carNumber, availableSlot.getSlotNumber(), parkingTime);
    }

    public PaymentReceipt unparkCar(String ticketId) {
        ParkingSession session = activeSessions.get(ticketId);

        if (session == null) {
            throw new InvalidTicketException("Invalid ticket ID");
        }

        int slotNumber = session.getSlotNumber();
        ParkingSlot slot = parkingSlots.get(slotNumber);
        String carNumber = slot.unparkCar();

        LocalDateTime unparkingTime = LocalDateTime.now();
        double charge = chargeCalculator.calculateCharge(session.getParkingTime(), unparkingTime);

        activeSessions.remove(ticketId);

        return new PaymentReceipt(ticketId, carNumber, charge, unparkingTime);
    }

    private ParkingSlot findAvailableSlot() {
        for (ParkingSlot slot : parkingSlots.values()) {
            if (!slot.isOccupied()) {
                return slot;
            }
        }
        return null;
    }

    private String generateTicketId() {
        return "TKT_" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
}
