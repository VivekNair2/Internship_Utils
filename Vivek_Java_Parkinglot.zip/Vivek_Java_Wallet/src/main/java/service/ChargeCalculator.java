package service;

import constants.ParkingConstants;
import exceptions.InvalidTimeException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class ChargeCalculator {
    public double calculateCharge(LocalDateTime parkingTime, LocalDateTime unparkingTime) {
        if (unparkingTime.isBefore(parkingTime)) {
            throw new InvalidTimeException("Unparking time cannot be before parking time");
        }

        long hours = ChronoUnit.HOURS.between(parkingTime, unparkingTime);

        if (hours == 0) {
            return 0;
        }

        long days = hours / 24;
        long remainingHours = hours % 24;

        double charge = ParkingConstants.FIRST_DAY_CHARGE;

        if (days > 1) {
            charge += (days - 1) * ParkingConstants.SUBSEQUENT_DAY_CHARGE;
        }

        if (remainingHours > 0 && days > 0) {
            charge += ParkingConstants.SUBSEQUENT_DAY_CHARGE;
        }

        return charge;
    }
}
