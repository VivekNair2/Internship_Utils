package interfaces;

public interface Receipt {

    String getTicketId();
}
