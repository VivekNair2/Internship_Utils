package main

import (
	"database/sql"
	"fmt"
	
	_ "github.com/lib/pq"
)

func main() {

	connStr:="postgres://vivek:Connect@2026@postgres:5432/postgres?sslmode=disable"

	db, err := sql.Open("postgres", connStr)
	if err != nil {
		fmt.Println(err)
	}
	defer db.Close()

	err = db.Ping()
	if err != nil {
	    fmt.Println("Cannot connect:", err)
	}

	fmt.Println("Connected to Postgres!")
    query := `CREATE TABLE IF NOT EXISTS users (id SERIAL PRIMARY KEY, name TEXT, age INT)`
	_, err = db.Exec(query)
	

	query = `INSERT INTO users (name, age) VALUES ($1, $2)`
	_, err = db.Exec(query, "Vivek", 23)
	if err != nil {
		fmt.Println("Insert failed:", err)
	}

	fmt.Println("Row inserted successfully!")
}
