# Go Concurrency Exercises
Exercises for Golang's concurrency patterns.

![Image of excited gopher](https://golang.org/doc/gopher/pkg.png)

## How to take this challenge
1. *Only edit `main.go`* to solve the problem. Do not touch any of the other files.
2. If you find a `*_test.go` file, you can test the correctness of your solution with `go test`
3. If you get stuck, join us on [Discord](https://discord.com/invite/golang) or [Slack](https://invite.slack.golangbridge.org/)! Surely there are people who are happy to give you some code reviews (if not, find me via `@loong` ;) )

## Overview
| # | Name of the Challenge + URL           |
| - |:-------------|
| 1 | [Producer-Consumer](https://github.com/loong/go-concurrency-exercises/tree/main/1-producer-consumer)  |
| 3 | [Limit Service Time for Free-tier Users](https://github.com/loong/go-concurrency-exercises/tree/main/3-limit-service-time)  |

