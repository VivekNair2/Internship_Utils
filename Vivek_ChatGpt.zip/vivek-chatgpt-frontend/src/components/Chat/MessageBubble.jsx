import "./MessageBubble.css";
import { useState, useEffect } from "react";
import ContentCopyOutlinedIcon from "@mui/icons-material/ContentCopyOutlined";
import ThumbUpOutlinedIcon from "@mui/icons-material/ThumbUpOutlined";
import ThumbDownOutlinedIcon from "@mui/icons-material/ThumbDownOutlined";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import RefreshIcon from "@mui/icons-material/Refresh";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";

function MessageBubble({ text, sender, isLatest }) {
  const [displayedText, setDisplayedText] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  useEffect(() => {
  
    if (sender === "assistant" && isLatest) {
      setIsTyping(true);
      setDisplayedText("");
      
      let currentIndex = 0;
      const typingSpeed = 20; 
      const typeInterval = setInterval(() => {
        if (currentIndex < text.length) {
          setDisplayedText(text.substring(0, currentIndex + 1));
          currentIndex++;
        } else {
          setIsTyping(false);
          clearInterval(typeInterval);
        }
      }, typingSpeed);
      
      return () => clearInterval(typeInterval);
    } else {
      setDisplayedText(text);
      setIsTyping(false);
    }
  }, [text, sender, isLatest]);

  const handleCopy = () => {
    navigator.clipboard.writeText(displayedText);
  };

  return (
    <div className={`message-row ${sender}`}>
      <div className="message-content">
        <div className="message-bubble">
          {displayedText}
          {isTyping && <span className="typing-cursor">|</span>}
        </div>
        {sender === "assistant" && !isTyping && (
          <div className="message-actions">
            <button className="action-btn" onClick={handleCopy} title="Copy">
              <ContentCopyOutlinedIcon fontSize="small" />
            </button>
            <button className="action-btn" title="Good response">
              <ThumbUpOutlinedIcon fontSize="small" />
            </button>
            <button className="action-btn" title="Bad response">
              <ThumbDownOutlinedIcon fontSize="small" />
            </button>
            <button className="action-btn" title="Download">
              <FileDownloadOutlinedIcon fontSize="small" />
            </button>
            <button className="action-btn" title="Regenerate">
              <RefreshIcon fontSize="small" />
            </button>
            <button className="action-btn" title="More">
              <MoreHorizIcon fontSize="small" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default MessageBubble;