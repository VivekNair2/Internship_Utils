import "./ChatWindow.css";
import MessageBubble from "./MessageBubble";
import { useState, useRef, useEffect } from "react";
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import PersonAddAltOutlinedIcon from "@mui/icons-material/PersonAddAltOutlined";
import ChatBubbleOutlineIcon from "@mui/icons-material/ChatBubbleOutline";

function ChatWindow({
  conversations,
  activeChatId,
  setConversations,
  setActiveChatId,
}) {
  const [message, setMessage] = useState("");
  const selectedModel = "ChatGPT 5.2";
  const textareaRef = useRef(null);
  const messagesEndRef = useRef(null);

  const activeChat = conversations.find((chat) => chat.id === activeChatId);

 
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeChat?.messages]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = textareaRef.current.scrollHeight + "px";
    }
  }, [message]);

  const handleSend = (e) => {
    e?.preventDefault();
    if (!message.trim()) return;

    let currentChatId = activeChatId

    if (!activeChat) {
      const newChat = {
        id: Date.now(),
        messages: [],
      };

      currentChatId = newChat.id;

      setConversations((prev) => [newChat, ...prev]);
      setActiveChatId(newChat.id);
    }

    const userMessage = {
      id: Date.now(),
      text: message,
      sender: "user",
    };

    setConversations((prev) =>
      prev.map((chat) =>
        chat.id === currentChatId
          ? {
              ...chat,
              messages: [...chat.messages, userMessage],
            }
          : chat,
      ),
    );

    setMessage("");
 
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }

    setTimeout(() => {
      const assistantMessage = {
        id: Date.now() + 1,
        text: "Hello this is a Chatgpt built by Vivek. This is a sample response to demonstrate the chat interface",
        sender: "assistant",
      };

      setConversations((prev) =>
        prev.map((chat) =>
          chat.id === currentChatId
            ? {
                ...chat,
                messages: [...chat.messages, assistantMessage],
              }
            : chat,
        ),
      );
    }, 1000);
  };

  const hasMessages = activeChat && activeChat.messages.length > 0;

  return (
    <div className="chat-window">
      <div className="chat-header">
        <div className="model-selector">
          <span className="model-name">{selectedModel}</span>
          <KeyboardArrowDownIcon className="dropdown-icon" />
        </div>
        <div className="header-actions">
          <button className="header-btn" title="Temporary chat">
            <PersonAddAltOutlinedIcon fontSize="small" />
          </button>
          <button className="header-btn" title="Create group">
            <ChatBubbleOutlineIcon fontSize="small" />
          </button>
        </div>
      </div>
      
      <div className={`chat-content ${!hasMessages ? "centered" : ""}`}>
        {hasMessages && (
          <div className="messages-area">
            {activeChat.messages.map((msg, index) => (
              <MessageBubble
                key={msg.id}
                text={msg.text}
                sender={msg.sender}
                isLatest={index === activeChat.messages.length - 1 && msg.sender === "assistant"}
              />
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}

        <div className="input-area">
          {!hasMessages && (
            <div className="greeting-text">What's on your Agenda today?</div>
          )}
          <div className="input-container">
            <form onSubmit={handleSend} className="input-form">
              <textarea
                ref={textareaRef}
                className="chat-input"
                placeholder="Ask anything"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend(e);
                  }
                }}
                rows={1}
              />
              <button
                type="submit"
                className={`send-button ${message.trim() ? "active" : ""}`}
                disabled={!message.trim()}
              >
                <ArrowUpwardIcon fontSize="small" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ChatWindow;
