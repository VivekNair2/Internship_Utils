import { useState } from "react";
import "./App.css";
import Sidebar from "./components/Sidebar/Sidebar";
import ChatWindow from "./components/Chat/ChatWindow";

function App() {
  const [conversations, setConversations] = useState([]);
  const [activeChatId, setActiveChatId] = useState(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <div className="app">
      <Sidebar
      conversations={conversations}
      activeChatId={activeChatId}
      setActiveChatId={setActiveChatId}
      setConversations={setConversations}
      isSidebarOpen={isSidebarOpen}
      setIsSidebarOpen={setIsSidebarOpen}
      />

      <ChatWindow
        conversations={conversations}
        activeChatId={activeChatId}
        setConversations={setConversations}
        setActiveChatId={setActiveChatId}
      />
    </div>
  );
}

export default App;