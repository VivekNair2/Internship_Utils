package geometry;

import geometry.errors.InvalidDimensionException;
import geometry.errors.NumericOverflowException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SquareTest {

    static class TestCase {
        String description;
        double inputSide;
        double expectedArea;
        double expectedPerimeter;
        Class<? extends RuntimeException> expectedError;

        TestCase(String description,
                 double inputSide,
                 double expectedArea,
                 double expectedPerimeter,
                 Class<? extends RuntimeException> expectedError) {
            this.description = description;
            this.inputSide = inputSide;
            this.expectedArea = expectedArea;
            this.expectedPerimeter = expectedPerimeter;
            this.expectedError = expectedError;
        }
    }

    @Test
    void Test_PerimeterAndAreaOfSquare() {
        TestCase[] tests = {
                new TestCase(
                        "Test should return area 25 when side is 5",
                        5, 25, 20, null
                ),
                new TestCase(
                        "Test should return area 4 when side is 2",
                        2, 4, 8, null
                ),
                new TestCase(
                        "Test should return area 0 when side is 0",
                        0, 0, 0, null
                ),
                new TestCase(
                        "Test should return error when side is -3",
                        -3, 0, 0, InvalidDimensionException.class
                ),
                new TestCase(
                        "Test should return error when side is 1e308",
                        1e308, 0, 0, NumericOverflowException.class
                )
        };

        for (TestCase tc : tests) {
            if (tc.expectedError != null) {
                assertThrows(tc.expectedError, () -> {
                    Square square = new Square(tc.inputSide);
                    square.area();
                }, tc.description);
            } else {
                Square square = new Square(tc.inputSide);

                assertEquals(tc.expectedArea, square.area(), tc.description);
                assertEquals(tc.expectedPerimeter, square.perimeter(), tc.description);
            }
        }
    }
}
