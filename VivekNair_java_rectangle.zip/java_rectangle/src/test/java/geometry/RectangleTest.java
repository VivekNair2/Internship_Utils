package geometry;

import geometry.errors.InvalidDimensionException;
import geometry.errors.NumericOverflowException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RectangleTest {

    static class TestCase {
        String description;
        double inputWidth;
        double inputHeight;
        double expectedArea;
        double expectedPerimeter;
        Class<? extends RuntimeException> expectedError;

        TestCase(String description,
                 double inputWidth,
                 double inputHeight,
                 double expectedArea,
                 double expectedPerimeter,
                 Class<? extends RuntimeException> expectedError) {
            this.description = description;
            this.inputWidth = inputWidth;
            this.inputHeight = inputHeight;
            this.expectedArea = expectedArea;
            this.expectedPerimeter = expectedPerimeter;
            this.expectedError = expectedError;
        }
    }

    @Test
    void Test_PerimeterAndAreaOfRectangle() {
        TestCase[] tests = {
                new TestCase("Test should return area 50 perimeter 30 when width is 10 and length is 5", 10, 5, 50, 30, null),
                new TestCase("Test should return area 16 perimeter 16 when width is 4 and height is 4", 4, 4, 16, 16, null),
                new TestCase("Test should return area 0 and perimeter 10 when width is 0 and height is 5", 0, 5, 0, 10, null),
                new TestCase("Test should return area 0 and perimeter 0 when width is -5 and height is 10", -5, 10, 0, 0, InvalidDimensionException.class),
                new TestCase("Test should return error when width 5 and  height is -10", 5, -10, 0, 0, InvalidDimensionException.class),
                new TestCase("Test should return error when width 1e308 and  height is 1e308", 1e308, 1e308, 0, 0, NumericOverflowException.class)
        };

        for (TestCase tc : tests) {
            if (tc.expectedError != null) {
                assertThrows(tc.expectedError, () -> {
                    Rectangle rect = new Rectangle(tc.inputWidth, tc.inputHeight);
                    rect.area();
                }, tc.description);
            } else {
                Rectangle rect = new Rectangle(tc.inputWidth, tc.inputHeight);

                assertEquals(tc.expectedArea, rect.area(),
                        tc.description + " - area failed");

                assertEquals(tc.expectedPerimeter, rect.perimeter(),
                        tc.description + " - perimeter failed");
            }
        }
    }
}
