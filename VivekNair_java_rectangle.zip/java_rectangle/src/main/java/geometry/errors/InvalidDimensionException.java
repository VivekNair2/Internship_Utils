package geometry.errors;

public final class InvalidDimensionException extends RuntimeException {

    public InvalidDimensionException(String message) {
        super(message);
    }
}



