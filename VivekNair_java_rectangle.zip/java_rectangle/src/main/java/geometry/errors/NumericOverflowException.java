package geometry.errors;

public final class NumericOverflowException extends RuntimeException {

    public NumericOverflowException(String message) {
        super(message);
    }
}
