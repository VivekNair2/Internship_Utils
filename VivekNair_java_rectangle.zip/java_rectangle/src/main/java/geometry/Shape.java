package geometry;

public interface Shape {
    double area();
    double perimeter();

    class Rectangle {
    }
}
