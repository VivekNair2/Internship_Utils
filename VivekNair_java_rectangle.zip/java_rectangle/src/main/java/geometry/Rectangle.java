package geometry;

import geometry.errors.InvalidDimensionException;
import geometry.errors.NumericOverflowException;

public class Rectangle implements Shape {
    private double width;
    private double height;

    public Rectangle(double width, double height) {
        if (width < 0 || height < 0) {
            throw new InvalidDimensionException("Width and height must be non-negative");
        }
        if (Double.isNaN(width) || Double.isNaN(height)) {
            throw new InvalidDimensionException("Dimensions cannot be NaN");
        }
        this.width = width;
        this.height = height;
    }

    @Override
    public double area() {
        double result = width * height;

        if (Double.isInfinite(result) || Double.isNaN(result)) {
            throw new NumericOverflowException("Numeric overflow in area");
        }

        return result;
    }

    @Override
    public double perimeter() {
        double result = 2 * (width + height);

        if (Double.isInfinite(result) || Double.isNaN(result)) {
            throw new NumericOverflowException("Numeric overflow in perimeter");
        }

        return result;
    }
}
