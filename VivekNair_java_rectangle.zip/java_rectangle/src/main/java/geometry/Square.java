package geometry;

import geometry.errors.InvalidDimensionException;
import geometry.errors.NumericOverflowException;

public class Square implements Shape {
    private double side;

    public Square(double side) {
        if (side < 0) {
            throw new InvalidDimensionException("Side must be non-negative");
        }
        if (Double.isNaN(side)) {
            throw new InvalidDimensionException("Side cannot be NaN");
        }
        this.side = side;
    }

    @Override
    public double area() {
        double result = side * side;

        if (Double.isInfinite(result) || Double.isNaN(result)) {
            throw new NumericOverflowException("Numeric overflow in area");
        }

        return result;
    }

    @Override
    public double perimeter() {
        double result = 4 * side;

        if (Double.isInfinite(result) || Double.isNaN(result)) {
            throw new NumericOverflowException("Numeric overflow in perimeter");
        }

        return result;
    }
}
